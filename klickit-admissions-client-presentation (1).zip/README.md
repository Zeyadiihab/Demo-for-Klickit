# Klickit Admissions — Stakeholder Demo

An interactive front-end prototype exploring an admissions workflow for schools using Klickit. This project is intended for product walkthroughs, stakeholder feedback, and design discussions.

> **Prototype notice:** This is a demonstration, not a production admissions system. Use fictional sample information only. Do not enter real student, parent, or other confidential data.

## What this demo is for

- Walk through the admissions experience from the perspective of school administrators and parents.
- Discuss workflow, navigation, application status, and information hierarchy.
- Gather stakeholder feedback before deciding on production requirements.

## Running locally

No build step is required for this standalone HTML prototype.

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

Some browser features may behave differently when opened as a local file. For a hosted walkthrough, use a hosting option with access restrictions enabled.

## Recommended sharing setup

This repository is intended to remain private while the demo is shared only with selected stakeholders.

- Keep the GitHub repository **Private** and grant repository access only to collaborators who need the source.
- Do not assume a private repository makes a GitHub Pages website private. GitHub Pages sites are public by default unless private Pages access control is available and configured through GitHub Enterprise Cloud.
- For a restricted live presentation, use an approved host that supports password protection or authenticated access, and test access in a signed-out/private browser window before sharing.
- If you do use GitHub Pages, confirm the site's visibility setting before distributing the URL.

## Suggested stakeholder walkthrough

1. **Context:** Explain the admissions problem and the intended users.
2. **Administrator experience:** Review the school-side workflow and the information used to manage applications.
3. **Parent experience:** Walk through the parent-facing flow and the information a family needs.
4. **Feedback:** Ask stakeholders what is clear, what is missing, and which steps need validation.
5. **Next steps:** Separate prototype feedback from requirements for authentication, data storage, permissions, integrations, and production readiness.

## Feedback prompts

- Does the workflow match how admissions are managed today?
- Which status changes or handoffs need to be explicit?
- What information should each user role be allowed to see or change?
- Which integrations or operational rules must be validated before implementation?

## Scope and limitations

This repository contains a browser-based prototype. It should not be treated as a secure or production-ready system, and a static website alone does not provide a shared production database, user authorization, or server-side business logic.

## Project file

- `index.html` — standalone interactive prototype, including its embedded styles and scripts.
